/**
 * Created by CongCong on 2017/2/20 0020.
 */
var liWidth = $('.slider li').width(); //获取slider下li的宽度
var size = $('.slider li').size();  //获取slider下li的个数
$('.slider').width(liWidth * size + 'px'); //设置ul的宽度
var index = 0; //初始值为0
$('.bar .index li').click(function () {  //为小圆点绑定单击事件
    index = $(this).index(); //获取当前li的下标，赋值给index
    $(this).addClass('active').siblings().removeClass('active');  //切换小圆点的样式
    imgToggle(this, index); //调用图片切换方法，实现slider下的li的滑动效果
});

/*计算每次点击的时候当前显示的index值   ---Begin*/
function getIdx(a) {
    var arr = $(a).siblings('.bar').children('.index').children('li');
    for (var i = 0; i < arr.length; i++) {
        if ($(arr[i]).hasClass('active')) {
            return i;
        }
    }
}

/* 为prev箭头绑定单击事件 */
$('.prev').on('click', function (e) {
    e.preventDefault();
    index = getIdx(this);
    if (index == 0) {
        return;
    }
    index--;
    imgToggle(this, index);
});

/* 为next箭头绑定单击事件 */
$('.next').on('click', function (e) {
    e.preventDefault();
    index = getIdx(this);
    if (index == $(this).siblings('.bar').children('.index').children('li').length-1) {
        return;
    }
    index++;
    imgToggle(this, index);
});

/* 定义一个方法，实现图片滑动效果 */
function imgToggle(self, index) {
    if (self.nodeName == 'A') { //判断当前点击的是否是箭头
        $(self).siblings('.content').find('.slider').stop(true).animate({
            "marginLeft": -liWidth * index + 'px'
        }, 500);
        //切换小圆点样式
        $(self).siblings('.bar').find('.index>li').removeClass('active').eq(index).addClass('active');
    } else { //否则，如果当前点击的是小圆点时，进行底下的操作
        $(self).parent().parent().siblings('.content').find('.slider').stop(true).animate({
            "marginLeft": -liWidth * index + 'px'
        }, 500);

        //切换小圆点样式
        $(self).parent().parent().siblings('.bar').find('.index>li').removeClass('active').eq(index).addClass('active');
    }
}