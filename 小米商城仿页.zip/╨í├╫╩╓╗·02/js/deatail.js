$(".container").hide();
$(window).scroll(function(){
	var top = $(document).scrollTop();
	if(top>900){
		$(".container").fadeIn(1000);
	}else{
		$(".container").fadeOut(500);
	}
});
$(function(){
	//显示div中的第一个图片
	$(".slide_one .silde_two").eq(0).show();
	//鼠标滑过手动切换，淡入淡出
	$(".pagination a").mouseover(function(){
		$(this).addClass("active").siblings().removeClass("active");
		var index = $(this).index();
		i=index;
		$(".slide_one .slide_two").eq(index).fadeIn().siblings().fadeOut();
		});
		//自动轮播
		var i=0;
		timer=setInterval(play,2000);
		//向右切换
		var play=function(){
			i++;
			i=i>3? 0 : i;
			$(".pagination a").eq(i).addClass('active').siblings().removeClass("active");
			$(".slide_one .slide_two").eq(i).fadeIn(500).siblings().fadeOut(500);
		}
		var playLeft=function(){
			i--;
			i = i<0? 3 : i;
			$(".pagination a").eq(i).addClass('active').siblings().removeClass("active");
			$(".slide_one .slide_two").eq(i).fadeIn(500).siblings().fadeOut(500);
		} 
		//鼠标移入移出效果
		$(".silide_one .slide_two").hover(function(){
			clearInterval(timer);
		},function(){
			timer=setInterval(play,2000);
		});
		//左右点击切换
		$(".slide-previous").click(function(){
			playLeft();
		})
		$(".slide-next").click(function(){
			play();
		})
})