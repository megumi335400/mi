$(function(){
	var i=0;
	var imgWidth=$("#container #content li").width();
	var clone=$("#container #content li").first().clone();
	$("#content").append(clone);
	var size=$("#container #content li").size();
	for(var j=0;j<size-1;j++){
		$("#controler").append("<div></div>");
	}
	$("#controler div").eq(0).addClass("onclick");
	$("#leftBtn").click(function(){
		Toright();
	});
	$("#rightBtn").click(function(){
		Toleft();
	});
	$("#controler div").hover(function(){
		i=$(this).index();
		clearInterval(timer);
		console.log(-i * imgWidth);
		$("#content").stop().animate({left: -i * imgWidth},1000);
		$(this).addClass("onclick").siblings().removeClass("onclick");
	},function(){
		timer = setInterval(function(){
			Toleft();
		},4000)
	})
	
	var timer = setInterval(function(){
			Toleft();
		},4000)
	function Toleft(){
		i++;
		if(i==size){
			$("#content").css({left:0});
			i=1;
		}
		$("#content").stop().animate({left: -i * imgWidth}, 1000);
		if (i == size - 1) {
            $("#controler div").eq(0).addClass("onclick").siblings().removeClass("onclick");
        } else {
            $("#controler div").eq(i).addClass("onclick").siblings().removeClass("onclick");
		 }
	   }
	   function Toright(){
		i--;
		if (i == -1) {
            $("#content").css({left: -(size - 1) * imgWidth});
            i = size - 2;
        }
        $("#content").animate({left: -i * imgWidth}, 1000);
        $("#controler div").eq(i).addClass("onclick").siblings().removeClass("onclick");
	   }
})

